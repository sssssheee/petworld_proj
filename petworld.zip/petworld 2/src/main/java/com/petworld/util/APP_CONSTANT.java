package com.petworld.util;

public class APP_CONSTANT {
	///Users/seungheelee/Desktop/FileUpload/
	public static final String uploadPath = "C:/dev/upload/";
		
	

}
