package com.petworld.util;

import lombok.Data;

@Data
public class DateVO {
	private String fromDate="";
	private String toDate="";
}
