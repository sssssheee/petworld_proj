package com.petworld.util.interceptor;
import org.springframework.web.servlet.HandlerInterceptor;

public class AdminAuthSuccessHandler implements HandlerInterceptor{
	
	// 성공하면 원래 있던 페이지로
	
	// 실패하면 관리자 계정으로 로그인 해야 합니다. 알러트. 로그아웃 뒤, 로그인 페이지로
	
}
