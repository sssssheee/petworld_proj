package com.petworld.mapper;

public interface ReplyMapper {

}
